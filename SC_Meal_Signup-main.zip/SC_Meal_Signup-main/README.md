# SC_Meal_Signup
Portal for CG members to submit what food they are bringing
